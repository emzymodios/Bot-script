# 🔥 Menu Script - Phiên Bản Premium V2.0

## 📝 Giới Thiệu
Đây là phiên bản **Premium Beautified** được thiết kế lại hoàn toàn, tối ưu cho GitHub + Render deployment.

---

## ✨ Tính Năng Nổi Bật

### 🎨 **Giao Diện Sang Trọng**
```
╔════════════════════════════════════════╗
║  🔥 SCRIPT HUB STORE
║  ⚡ Kho Script Game Roblox Uy Tín
║
║  📋 Chọn Script Hub bên dưới
║  ✅ Tất cả script đều hoạt động tốt
║  🔒 An toàn - Được kiểm duyệt
╚════════════════════════════════════════╝
```

**Features:**
- ✅ Thumbnail icon chuyên nghiệp
- ✅ Embed fields tổ chức khoa học
- ✅ Color scheme bắt mắt (Red/Pink #FF6B6B)
- ✅ Footer branding rõ ràng
- ✅ ASCII decorative boxes

### 📋 **Danh Mục Script Tổ Chức**

#### ⭐ **Popular & Trending**
- Hop Night Hub ⚡
- Main Night Hub 🎬
- Terror Hub 💀
- Omg Hub ✨

#### 🎮 **Game Specific**
- Teddy Hub 🧸
- Redz Fake 🔴
- Koko Hub 🥥
- Realkid Hub 🧒

#### 🛠️ **Utilities & Tools**
- Fix Lag 🛠️
- Fly Gui V3 ⚡
- Forge Hub 🔧
- Main Hoho Hub 🔥

#### 🌟 **Special & Unique**
- Trẩu V9 😈
- Steal A Brainrot 🧠
- Grow A Garden 2 🌱
- Banana Fake ▶️
- Quantum Hub 🌌

### 🎯 **Chi Tiết & Mô Tả**
- Mỗi script có mô tả riêng chi tiết
- Emoji phù hợp cho từng loại
- Highlight tính năng chính

---

## 🔧 Cấu Trúc Code

```
CONFIG
├── ADMIN_ROLES      // Danh sách role Admin có quyền
├── COLORS          // Màu sắc (Primary, Secondary, Accent, Dark)
└── MENU            // Cấu hình menu

SCRIPT_HUBS[]       // Danh sách 17 Script Hub
                    // Được sắp xếp theo category

FUNCTIONS
├── isAdmin()            // Kiểm tra quyền Admin
├── createErrorEmbed()   // Tạo embed lỗi đẹp
├── createMenuEmbed()    // Tạo embed menu premium
└── createSelectMenu()   // Tạo select menu

EXPORT
└── module.exports   // Slash command export
```

---

## 🚀 Cách Sử Dụng

### 1️⃣ **Setup Bot**
```bash
# Clone repo từ GitHub
git clone your-repo-url

# Install dependencies
npm install

# Start bot
npm start
```

### 2️⃣ **Thay Thế File**
```
Thay thế file: commands/menu.js
Bằng file mới: menu.js
```

### 3️⃣ **Reload Bot**
- Restart bot hoặc reload command
- Hoặc dùng Render auto-deploy từ GitHub

### 4️⃣ **Sử Dụng Command**
```
Gõ: /menu
```

---

## ⚙️ Tùy Chỉnh & Config

### 🎨 **Thay Đổi Màu**
```javascript
COLORS: {
    PRIMARY: '#FF6B6B',    // Màu chính (Red/Pink)
    SECONDARY: '#4ECDC4',  // Màu phụ (Teal)
    ACCENT: '#FFE66D',     // Màu accent (Yellow)
    DARK: '#1A1A2E'        // Màu tối (Dark)
}
```

### 👥 **Thêm Admin Roles**
```javascript
ADMIN_ROLES: [
    '1420260959913775155',
    '1420753551587807353',
    '1420262154271199283',
    'ROLE_ID_MỚI'  // Thêm role ID ở đây
]
```

### 📝 **Thêm Script Hub Mới**
```javascript
const SCRIPT_HUBS = [
    // ... Script cũ
    {
        label: '✨ Tên Script Mới',
        description: 'Mô tả chi tiết',
        value: 'script_id_unique',
        emoji: '🎯'
    }
];
```

### 🎯 **Thay Đổi Placeholder Text**
```javascript
MENU: {
    CUSTOM_ID: 'shop_menu',
    PLACEHOLDER: '🔍 Tùy chỉnh text ở đây...',
    TITLE: '🔥 SCRIPT HUB STORE',
    SUBTITLE: '⚡ Kho Script Game Roblox Uy Tín'
}
```

---

## 📦 Dependencies

```json
{
  "discord.js": "^14.0.0"
}
```

Yêu cầu Node.js v16+

---

## 🔄 Deployment với GitHub + Render

### GitHub Setup:
1. Push code lên GitHub
```bash
git add .
git commit -m "Update menu script v2.0"
git push origin main
```

2. Render sẽ auto-deploy khi detect push

### Render Config:
- **Build Command**: `npm install`
- **Start Command**: `node index.js`
- **Environment**: Node.js

---

## 🐛 Troubleshooting

### ❌ Command không hiện?
- Restart bot
- Check bot có permission slash commands không
- Check bot token đúng không

### ❌ Embed không hiện?
- Check console log error message
- Verify bot có permission embed links
- Check image URL có đúng không

### ❌ Select Menu không work?
- Check interactionCreate event handler đang running
- Verify custom ID khớp nhau
- Check bot có permission use slash commands

### ❌ Không có quyền?
- Check role ID đúng không
- Thêm role vào ADMIN_ROLES config
- Restart bot sau khi update config

---

## 📊 Thông Tin Script

**Total Scripts:** 17  
**Categories:** 4 (Popular, Game Specific, Tools, Special)  
**Last Updated:** 2024  
**Version:** 2.0 Premium

---

## 💡 Best Practices

✅ **Luôn backup code trước khi edit**  
✅ **Test trên dev server trước khi push production**  
✅ **Keep dependencies updated**  
✅ **Monitor console logs cho errors**  
✅ **Document khi add tính năng mới**

---

## 📞 Support & Issues

- Kiểm tra console log: `node index.js`
- Check Discord.js docs: https://discord.js.org
- GitHub Issues: `git push` và report lỗi

---

## 📄 License & Credits

Made with ❤️ for Script Hub Community  
**Discord.js** - Discord API Library  
**Premium Design** - Custom beautified theme

---

## 🎯 Roadmap (Future)

- [ ] Thêm categories modal
- [ ] Thêm script info command
- [ ] Thêm download links
- [ ] Thêm user reviews
- [ ] Thêm statistics

---

**Version:** 2.0 Premium  
**Last Updated:** September 2024  
**Status:** ✅ Production Ready
